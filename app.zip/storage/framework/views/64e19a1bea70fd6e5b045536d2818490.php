<?php echo $__env->make('partials.head', ['title' => 'Hola mundo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    function deletePost(e, id) {
        if (!confirm('Are you sure you want to delete this announcement?\nTHIS ACTION CANNOT BE REVERSED.')) {
            return;
        }
        const btn = e.target
        btn.disabled = true

        const uri = "<?php echo e(url('/announcements')); ?>/" + id;

        const requestOptions = {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        };
        fetch(uri, requestOptions)
            .then((res) => {
                if (res.status !== 200) {
                    const msg = document.createElement('span')
                    msg.classList.add('alert')
                    msg.classList.add('error')
                    msg.textContent =
                        "The removal of the publication could not be completed, check the console for more information."
                    btn.parentNode.appendChild(msg);
                    console.log(res)
                } else {
                    const msg = document.createElement('span')
                    msg.classList.add('alert')
                    msg.classList.add('success')
                    msg.textContent =
                        "Post successfully deleted."
                    const nodeGod = btn.parentNode.parentNode;
                    nodeGod.innerHTML = "";
                    nodeGod.appendChild(msg);
                }
            })
            .catch(error => console.error('Error:', error));
    }
</script>

<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>

        <h1 class="centered">Announcements</h1>

        <?php if(Auth::user()['role'] == 'admin'): ?>

            <form action="/say" method="POST">
                <?php echo csrf_field(); ?>
                <h1>Create announcement </h1>
                <p>Create an announcement for all your customers, they will see the announcements in the [Announcements]
                    tab.
                </p>
                <?php if(session('response')): ?>
                    <span class="alert <?php echo e(session('response')['type']); ?>">
                        <?php echo e(session('response')['message']); ?>

                    </span>
                <?php endif; ?>
                <hr>

                <div class="vertical-input">
                    <label for="title" style="width: 90%">Title</label>
                    <input style="width: 90%" required type="text" name="title" id="title"
                        placeholder="Announcement title">

                </div>

                <div class="vertical-input">
                    <label for="content" style="width: 90%">Content</label>
                    <textarea required name="content" id="content" cols="30" rows="10" style="width: 90%"></textarea>
                </div>

                <hr>
                <input type="submit" value="Post" style="margin-left: 30px">
            </form>
        <?php endif; ?>

        <?php if($data): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">
                    <h2><?php echo e($post['title']); ?></h2>
                    <span><?php echo e($post['created_at']); ?></span>
                    <?php $__currentLoopData = $post['content']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>
                            <?php echo e($paragraph); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(Auth::user()['role'] == 'admin'): ?>
                        <div class="buttons">
                            <button onclick="deletePost(event,<?php echo e($post['id']); ?>)">Remove</button>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p style="text-align: center;">
                There are no announcements yet.
            </p>
        <?php endif; ?>

        <br><br>
    </main>
</body>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/client/announcements.blade.php ENDPATH**/ ?>