<?php echo $__env->make('partials.head', ['title' => 'Hola mundo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <form action=<?php echo e(url('users/register')); ?> method="post">
            <?php echo csrf_field(); ?>
            <h1>Register a new user.</h1>
            <p>Register a new user as a customer or as an account administrator.</p>
            <?php if(session('response')): ?>
                <span class="alert <?php echo e(session('response')['type']); ?>">
                    <?php echo e(session('response')['message']); ?>

                </span>
            <?php endif; ?>
            <hr>
            <div class="horizontal-input">
                <label for="name">First name</label>
                <input type="text" name="name" id="name" placeholder="First name" autocomplete="off" required>
            </div>

            <div class="horizontal-input">
                <label for="lastname">Lastname</label>
                <input type="text" name="lastname" id="lastname" placeholder="Lastname" autocomplete="off" required>
            </div>

            <div class="horizontal-input">
                <label for="Email">E-mail</label>
                <input type="email" name="email" id="email" placeholder="Enter Email" autocomplete="off"
                    required>
            </div>

            <div class="horizontal-input">
                <label for="password">Password</label>
                <div>
                    <label for="show">Show</label>
                    <input type="checkbox" name="show" id="show" onchange="toggleInputPass(event)">
                    <input type="password" name="password" id="password" placeholder="Password" autocomplete="off"
                        required>
                </div>
            </div>

            <div class="horizontal-input">
                <label for="balance">Balance</label>
                <input type="number" name="balance" id="balance" placeholder="Beginning balance" autocomplete="off"
                    step="0.01">
            </div>
            <hr>
            <div>
                <label for="admin">Administrator Account</label>
                <input type="radio" name="role" id="admin" value="admin">
            </div>

            <div>
                <label for="client">Client Account</label>
                <input type="radio" name="role" id="client" value="client" checked>
            </div>
            <hr>

            <div>
                <label for="isActive">Activate Account</label>
                <label class="switch">
                    <input type="checkbox" name="isActive" id="isActive" checked>
                    <span class="slider"></span>
                </label>
            </div>

            <hr>
            <input type="submit" value="Create">
            <a href="/users" style="margin-left: 18px;font-weight: 400;">Back</a>

        </form>
        <br><br>

    </main>
</body>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/client/register.blade.php ENDPATH**/ ?>