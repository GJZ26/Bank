<?php echo $__env->make('partials.head', ['title' => 'Hola mundo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    function calculaterCurrentBalance(e){
        const initial_value = <?php echo e(Auth::user()['balance']); ?>;
        document.getElementById("actual").textContent = `$${(initial_value - e.target.value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD`
    }
</script>
<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <form action=<?php echo e(url('/transfer')); ?> method="post">
            <?php echo csrf_field(); ?>
            <h1>Transfer</h1>
            <p>Transfer your credit to another user by means of their account number.</p>
            <hr>
            <div class="horizontal-input">
                <label for="sender">Sender's account number</label>
                <input type="number" name="sender" id="sender" value="<?php echo e(Auth::user()['account']); ?>" disabled>
            </div>
            <div class="horizontal-input">
                <label for="recipient">Recipient's account number</label>
                <input type="number" name="recipient" id="recipient" placeholder="20-digit account number" required
                    <?php echo e(Auth::user()['isActive'] ? '' : 'disabled'); ?>>
            </div>
            <div class="horizontal-input">
                <label for="amount">Amount (USD)</label>
                <input type="number" name="amount" id="amount" max="<?php echo e(Auth::user()['balance']); ?>" min="0"
                    step="0.01" placeholder="Amount to be transferred"
                    <?php echo e(Auth::user()['isActive'] ? '' : 'disabled'); ?> required style="width: 189px"
                    oninput="calculaterCurrentBalance(event)">
            </div>
            <div class="horizontal-input">
                <label for="concept">Concept</label>
                <input type="text" name="concept" id="concept" placeholder="Concept"
                    <?php echo e(Auth::user()['isActive'] ? '' : 'disabled'); ?>>
            </div>
            <hr>
            <input type="submit" value="Transfer" <?php echo e(Auth::user()['isActive'] ? '' : 'disabled'); ?>>
            <p>Your balance after the transfer: <span id="actual"
                    style="font-weight: 400;">$<?php echo e(number_format(Auth::user()['balance'], 2)); ?> USD</span></p>

            <?php if(!Auth::user()['isActive']): ?>
                <span class="alert warn">
                    Your account is inactive, you cannot make transfers at this time.
                </span>
            <?php endif; ?>

            <?php if(session('response')): ?>
                <span class="alert <?php echo e(session('response')['type']); ?>">
                    <?php echo e(session('response')['message']); ?>

                </span>
            <?php endif; ?>
        </form>
    </main>
</body>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/client/transfer.blade.php ENDPATH**/ ?>