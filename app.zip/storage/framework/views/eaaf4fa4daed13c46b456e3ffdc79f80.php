<?php echo $__env->make('partials.head', ['title' => 'Hola mundo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main style="margin-left: 200px">
        <div class="records">
            <h2>Transfer registers</h2>
            
            <table class="record">
                <tbody>
                    <tr>
                        <th>
                            Sender's Account
                            
                        </th>
                        <th>
                            Recipient's Account
                            
                        </th>
                        <th>
                            Amount
                            
                        </th>
                        <th>
                            Concept
                            
                        </th>
                        <th>
                            Date
                            
                        </th>
                    </tr>
                    <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td
                                style="<?php echo e($record['from'] === '<External-Account>' ? 'color: #aeaeae;font-style: italic;' : ''); ?>">
                                    <?php echo e($record['from'] === '<External-Account>'
                                            ? '<External-Account>'
                                            : ($record['from'] === Auth::user()['account']
                                                ? 'Your account'
                                                : implode('-', str_split($record['from'], 5))
                                            )); ?>

                                    
                                
                            </td>
                            <td>
                                <?php echo e(Auth::user()['account'] == $record['to'] ? ' Your account ' : implode('-', str_split($record['to'], 5))); ?>

                            </td>
                            <td>$<?php echo e(number_format($record['amount'], 2)); ?> USD</td>
                            <td
                                style="max-width: 186px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;<?php echo e(!isset($record['concept']) ? 'color: #aeaeae;font-style: italic;' : ''); ?>">
                                <?php echo e(isset($record['concept']) ? $record['concept'] : '[ No concept ]'); ?>

                            </td>
                            <td><?php echo e($record['created_at']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/client/history.blade.php ENDPATH**/ ?>