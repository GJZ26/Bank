<?php echo $__env->make('partials.head', ['title' => 'Hola mundo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    function askDelete(e, id, name) {
        if (!confirm('Are you sure you want to delete the user ' + name + '?\nTHIS ACTION CANNOT BE REVERSED.')) {
            return;
        }
        const btn = e.target.nodeName === 'I' ? e.target.parentNode : e.target
        btn.disabled = true
        const uri = "<?php echo e(url('/users')); ?>/" + id;

        const requestOptions = {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        };
        fetch(uri, requestOptions)
            .then((res) => {
                if (res.status === 200) {
                    btn.parentElement.parentNode.parentNode.removeChild(btn.parentElement.parentNode)
                }else{
                    console.log(res)
                }
            })
            .catch(error => console.error('Error:', error));
    }
</script>

<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <div class="records user">
            <h1>User list</h1>
            <p>Manage your customer users or administrators from this section or <a href="/users/register">add a new
                    one</a>.</p>
            <h2 class="admins">Administrators</h2>
            <table class="record">
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Lastname</td>
                        <td>Email</td>
                        <td>Actions</td>
                    </tr>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($admin['id']); ?></td>
                            <td><?php echo e($admin['name']); ?></td>
                            <td><?php echo e($admin['lastname']); ?></td>
                            <td><?php echo e($admin['email']); ?></td>
                            <td>
                                <a href=<?php echo e(url('/users/' . $admin['id'])); ?> style="color: #fff">
                                    <button class="edit"><i class="fa-solid fa-pen"></i></button>
                                </a>
                                <button class="delete"
                                    onclick="askDelete(event,<?php echo e($admin['id']); ?>, '<?php echo e($admin['name']); ?>')"><i
                                        class="fa-solid fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
            <h2>Clients</h2>
            <table class="record">
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Lastname</td>
                        <td>Account</td>
                        <td>Balance</td>
                        <td>Email</td>
                        <td>Status</td>
                        <td>Actions</td>
                    </tr>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($client['id']); ?></td>
                            <td><?php echo e($client['name']); ?></td>
                            <td><?php echo e($client['lastname']); ?></td>
                            <td><?php echo e(substr($client['account'], 0, 4) . '###' . substr($client['account'], -4)); ?></td>
                            <td>$<?php echo e(number_format($client['balance'], 2)); ?> USD</td>
                            <td><?php echo e($client['email']); ?></td>
                            <td class="<?php echo e($client['isActive'] ? 'active' : 'inactive'); ?>"><?php echo e($client['isActive'] ? 'Active' : 'Inactive'); ?></td>
                            <td>
                                <a href=<?php echo e(url('/users/' . $client['id'])); ?> style="color: #fff">
                                    <button class="edit">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>
                                </a>
                                <button class="delete"
                                    onclick="askDelete(event,<?php echo e($client['id']); ?>,'<?php echo e($client['name']); ?>')"><i
                                        class="fa-solid fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <br><br>
    </main>
</body>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/client/users.blade.php ENDPATH**/ ?>