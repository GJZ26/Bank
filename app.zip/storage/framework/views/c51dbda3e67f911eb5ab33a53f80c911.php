<nav>
    <div class="logo">
        <img src=<?php echo e(asset('images/logoRed.png')); ?> alt="Logo">
    </div>
    <div class="client-info">
        <img src=<?php echo e(asset('images/default-avatar.png')); ?> alt="Default Avatar">
        <div class="info">
            <h2>
                <?php echo e(explode(' ', Auth::user()['name'])[0]); ?> <?php echo e(explode(' ', Auth::user()['lastname'])[0]); ?>

            </h2>
            <p>
                <?php echo e(Auth::user()['role'] === 'client' ? 'Standard' : 'Admin'); ?> Account
            </p>
        </div>
    </div>
    <div class="tabs">


        <a href="/dashboard" <?php echo e(str_contains(request()->path(), 'dashboard') ? 'class=active' : ''); ?>>
            <i class="fa-solid fa-gauge-high"></i>Dashboard
        </a>
        <a href="/transfer" <?php echo e(str_contains(request()->path(), 'transfer') ? 'class=active' : ''); ?>>
            <i class="fa-solid fa-money-bill-transfer"></i>Transfers
        </a>

        <a href="/history" <?php echo e(str_contains(request()->path(), 'history') ? 'class=active' : ''); ?>>
            <i class="fa-solid fa-clock-rotate-left"></i>Transactions
        </a>

        <a href="/announcements" <?php echo e(str_contains(request()->path(), 'announcements') ? 'class=active' : ''); ?>

            class="notificated" notifications="9+">
            <i class="fa-solid fa-bullhorn"></i>Announcements
        </a>

        <?php if(Auth::user()['role'] == 'admin'): ?>
            <a href="/users" <?php echo e(str_contains(request()->path(), 'users') ? 'class=active' : ''); ?>>
                <i class="fa-solid fa-users"></i>Manage Users
            </a>
        <?php endif; ?>

        <a href="/logout">
            <i class="fa-solid fa-arrow-right-from-bracket"></i>Logout
        </a>
    </div>
</nav>
<?php /**PATH C:\Users\adolf\OneDrive\Documentos\Proyectos Personales\clienthub\resources\views/partials/nav.blade.php ENDPATH**/ ?>